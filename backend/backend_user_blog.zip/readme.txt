.env tiedostoon nämä
MONGODB_URI=mongodb+srv://TUNNUS:SALASANA@cluster0-s3qvc.mongodb.net/DB-NIMI?retryWrites=true&w=majority
PORT=3000
JWT_SECRET=JWT SALASANA